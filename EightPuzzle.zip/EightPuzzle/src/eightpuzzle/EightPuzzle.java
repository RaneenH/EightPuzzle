/*

ITBP 219 sec 56 - HW 3
 Instructor: Dr. Jose Berengueres 
 Student Name & ID:
 Raneen Herzalla   201350261

This is a HW for understanding 2D arrays and how they are implemented in classes.

Created: 22/10/2016

Date Modified                   Changes
24/10/2016                      -Made blank appear instead of 0 on gameboard
                                -Removed getRowIndex and getColumn index from the
                                 user as input, and instead created getZeroRow and
                                 getZeroColumn which is done by the program itself
                                -Added instructions for user
 */
package eightpuzzle;
import java.util.*;
public class EightPuzzle {
    Scanner read = new Scanner(System.in);
    private int[][] board=new int[3][3];
    private char choice;
    int[][] solution={{1,2,3},{4,5,6},{7,8,0}};
    
    public EightPuzzle(){
        for (int i=0; i<3 ; i++){
            for (int j=0;j<3;j++){
                this.board[i][j]=9;
            }
        for ( i=0; i<3 ; i++){
            for (int j=0;j<3;j++){
                do {this.board[i][j]=getRandomNum();
                }
                while (isSame(i,j));
            }
        }
        }
    }    
    public int getRandomNum (){
        int num;
        do {
            num=(int)((Math.random()*10));        
        }while (num>8);
        return num;
    }
    public boolean isSame (int i, int j){
        for (int k=0; k<3 ; k++){
            for (int l=0;l<3;l++){
                if (!(k==i && l==j)){
                    if (this.board[i][j]==this.board[k][l])
                        return true;
                }
            }
        }
        return false;
    }
    public void showBoard(){
        for (int i=0; i<3 ; i++){
            for (int j=0;j<3;j++){
               if (this.board[i][j]==0)
                    System.out.print("  ");
                else 
                System.out.print(this.board[i][j]+" ");
            }
            System.out.println();
    }
    }
    public int getZeroRowIndex(){
        for (int i=0; i<3 ; i++){
            for (int j=0;j<3;j++){
                if (this.board[i][j]==0)
                    return i;
            }
            
    }
        return -1;
    }
    public int getZeroColoumnIndex(){
        for (int i=0; i<3 ; i++){
            for (int j=0;j<3;j++){
                if (this.board[i][j]==0)
                    return j;
            }
            
    }
        return -1;
    }
    public String getMove (){
        return read.next();
    }
    public void move(char ch){
        int i,j;
        i=getZeroRowIndex();
        j=getZeroColoumnIndex();
        if (ch=='w'){
            this.board[i][j]=this.board[i-1][j];
            this.board[i-1][j]=0;
    }
        else if (ch=='s'){
            this.board[i][j]=this.board[i+1][j];
            this.board[i+1][j]=0;
    }
        else if (ch=='a'){
            this.board[i][j]=this.board[i][j-1];
            this.board[i][j-1]=0;
    }
            else if (ch=='d'){
            this.board[i][j]=this.board[i][j+1];
            this.board[i][j+1]=0;
    }
    }
    public boolean hasWon(){
        for (int i=0; i<3 ; i++){
            for (int j=0;j<3;j++){
                if (this.board[i][j]!=this.solution[i][j])
                    return false;
            }
        }
        return true;
    }
    public static void main(String[] args) {
        char move;
        int rowIndex, colIndex;
        System.out.println("\t\t888888888 Welcome to the Eight Puzzle Game 888888888"
                           + "\nInstructions:\n-Use W S A D from the keyboard"
                           + " to move the blank up, down, left, and right.\n "
                           + "You have unlimited number of tries."
                           + "\n Good Luck!!!\n");
        EightPuzzle test = new EightPuzzle();
        test.showBoard();
        while (!(test.hasWon())){
        //System.out.println("Make a move ");
        move=test.getMove().charAt(0);
        test.move(move);
        test.showBoard();
        }
        System.out.println("You Won!!!");
    }
    
}
